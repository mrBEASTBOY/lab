public interface ICalculator {
    int calculateSalary();
}