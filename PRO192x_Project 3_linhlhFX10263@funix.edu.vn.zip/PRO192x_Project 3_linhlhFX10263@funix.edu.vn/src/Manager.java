public class Manager extends Staff implements ICalculator {
    private String chucDanh;

    // Container.
    public Manager() {
        super();
    }
    public Manager(int id, String ten, int tuoi, double heSoLuong, String ngayBatDau, Department boPhanLamViec, int ngayNghiPhep, String chucDanh) {
        super(id, ten, tuoi, heSoLuong, ngayBatDau, boPhanLamViec, ngayNghiPhep);
        this.chucDanh = chucDanh;
    }

    // Getter.
    public String getChucDanh() {
        return chucDanh;
    }

    // Setter.
    public void setChucDanh(String chucDanh) {
        this.chucDanh = chucDanh;
    }

    @Override
    public String displayInformation() {
        return "ID: " + super.getId() + ", Tên: " + super.getTen() + ", Tuổi: " + super.getTuoi() + ", Hệ số lương: " + super.getHeSoLuong() + ", Ngày bắt đầu: " + super.getNgayBatDau() + ", Bộ phân làm việc: " + super.getBoPhanLamViec() + ", Số ngày nghỉ phép: " + super.getNgayNghiPhep() + ", Chức danh: " + this.chucDanh + ", Lương: " + calculateSalary();

    }

    @Override
    public int calculateSalary() {
        int luongTrachNhiem = 0;
        if(chucDanh.equalsIgnoreCase("Business Leader")) {
            luongTrachNhiem = 8000000;
        } else if(chucDanh.equalsIgnoreCase("Project Leader")) {
            luongTrachNhiem = 5000000;
        } else if(chucDanh.equalsIgnoreCase("Technical Leader")) {
            luongTrachNhiem = 6000000;
        }
        double salary =  super.getHeSoLuong() * 5000000 + luongTrachNhiem;
        return (int)salary;
    }
}