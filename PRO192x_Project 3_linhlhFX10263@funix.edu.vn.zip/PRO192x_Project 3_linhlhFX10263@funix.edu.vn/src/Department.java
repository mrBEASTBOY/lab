import java.util.List;

class Department {
    private int maBoPhan;
    private String tenBoPhan;
    private int soNhanVienBoPhan;

    // Container
    public Department() {
    }
    public Department(int maBoPhan, String tenBoPhan) {
        this.maBoPhan = maBoPhan;
        this.tenBoPhan = tenBoPhan;
    }
    public Department(int maBoPhan, String tenBoPhan, int soNhanVienBoPhan) {
        this.maBoPhan = maBoPhan;
        this.tenBoPhan = tenBoPhan;
        this.soNhanVienBoPhan = soNhanVienBoPhan;
    }

    // Setter
    public void setMaBoPhan(int maBoPhan) {
        this.maBoPhan = maBoPhan;
    }
    public void setTenBoPhan(String tenBoPhan) {
        this.tenBoPhan = tenBoPhan;
    }
    public void setSoNhanVienBoPhan(int soNhanVienBoPhan) {
        this.soNhanVienBoPhan = soNhanVienBoPhan;
    }

    // Getter
    public int getMaBoPhan() {
        return maBoPhan;
    }
    public String getTenBoPhan() {
        return tenBoPhan;
    }
    public int getSoNhanVienBoPhan() {
        return soNhanVienBoPhan;
    }

    public String toString() {
        return "Mã bộ phận: " + this.maBoPhan + ", tên bộ phận: " + this.tenBoPhan + ", số nhân viên bộ phận: " + this.soNhanVienBoPhan;
    }
}
