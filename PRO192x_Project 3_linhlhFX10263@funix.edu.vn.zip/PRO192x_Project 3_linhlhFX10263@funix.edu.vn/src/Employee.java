public class Employee extends Staff implements ICalculator {
    private int soGioLamThem;

    // Container.
    public Employee() {
        super();
    }
    public Employee(int id, String ten, int tuoi, double heSoLuong, String ngayBatDau, Department boPhanLamViec, int ngayNghiPhep, int soGioLamThem) {
        super(id, ten, tuoi, heSoLuong, ngayBatDau, boPhanLamViec, ngayNghiPhep);
        this.soGioLamThem = soGioLamThem;
    }

    // Getter.
    public int getSoGioLamThem() {
        return soGioLamThem;
    }

    // Setter.
    public void setSoGioLamThem(int soGioLamThem) {
        this.soGioLamThem = soGioLamThem;
    }

    @Override
    public String displayInformation() {
        return "ID: " + super.getId() + ", Tên: " + super.getTen() + ", Tuổi: " + super.getTuoi() + ", Hệ số lương: " + super.getHeSoLuong() + ", Ngày bắt đầu: " + super.getNgayBatDau() + ", Bộ phân làm việc: " + super.getBoPhanLamViec() + ", Số ngày nghỉ phép: " + super.getNgayNghiPhep() + ", Số giờ làm thêm: " + this.soGioLamThem + ", Lương: " + calculateSalary();
    }

    @Override
    public int calculateSalary() {
        double salary = super.getHeSoLuong() * 3000000 + soGioLamThem * 200000;
        return (int)salary;
    }
}


