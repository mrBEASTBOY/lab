import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class HumanResources {
    private static Scanner input = new Scanner(System.in);
    private static List<Department> departmentList;
    private static int count = 0;

    public static void main(String[] args) {
        ArrayList<Staff> arrStaffs = new ArrayList<Staff>(); // luu cac staff.
        // Nhập trước tên các bộ phận trong công ty.
        departmentList = new ArrayList<>(); // luu cac department.
        departmentList.add(new Department(1234, "Project"));
        departmentList.add(new Department(2345, "Technique"));
        departmentList.add(new Department(3456, "Business"));
        int choose, soNhanVien;
        do {
            // Hiển thị các lựa chọn trong chương trình có cho người dùng.
            System.out.println("Lựa chọn một trong số các chức năng cơ bản sau: ");
            System.out.println("1. Hiển thị danh sách nhân viên hiện có trong công ty");
            System.out.println("2. Hiển thị các bộ phận trong công ty.");
            System.out.println("3. Hiển thị các nhân viên theo từng bộ phận.");
            System.out.println("4. Thêm nhân viên mới vào công ty: bao gồm 2 loại");
            System.out.println("    - Thêm nhân viên thông thường");
            System.out.println("    - Thêm nhân viên là cấp quản lý (có thêm chức vụ)");
            System.out.println("5. Tìm kiếm thông tin nhân viên theo tên hoặc mã nhân viên");
            System.out.println("6. Hiển thị bảng lương của nhân viên toàn công ty");
            System.out.println("7. Hiển thị bảng lương của nhân viên theo thứ tự tăng dần");
            System.out.print("Lựa chọn: ");
            int answer = input.nextInt(); // Người dùng nhập lựa chọn.
            System.out.println();
            if(answer < 1 || answer > 7) { // Điều kiện nếu lựa chọn nhỏ hơn 1 hoặc lớn hơn 7 thì hiển thị lỗi.
                throw new InputMismatchException("Lựa chọn của bạn không hợp lệ");
            } else if(answer == 1) { // answer bằng 1 thì hiển thị danh sách nhân viên trong công ty.
                displayAllEmp(arrStaffs);
                System.out.println();
            } else if(answer == 2) { // answer bằng 2 thì hiển thị các bộ phận trong công ty.
                DisplayDepartmentInformation();
                System.out.println();
            } else if(answer == 3) { // answer bằng 3 thì hiển thị các nhân viên trong bộ phận.
                ShowAllEmpInDepartment(arrStaffs);
                System.out.println();
            } else if(answer == 4) { // answer bằng 4 thì thêm nhân viên hoặc quản lý cấp cao.
                System.out.print("Nhập số lượng nhân viên bạn muốn thêm: "); // Yêu cầu người dùng nhập số lượng nhân viên muốn thêm vào.
                soNhanVien = input.nextInt();
                count += soNhanVien;
                for(int i = 0; i < soNhanVien; i++) { // Tạo vòng lặp với i < soNhanVien.
                    System.out.println("Chọn loại nhân viên bạn muốn thêm vào: "); // Đưa lựa chọn cho người dùng muốn thêm nhân viên thông thường hay quản lý cấp cao.
                    System.out.println("1. Thêm nhân viên thông thường");
                    System.out.println("2. Thêm nhân viên là cấp quản lý (có thêm chức vụ)");
                    System.out.print("Lựa chọn: ");
                    choose = input.nextInt();
                    if (choose < 1 || choose > 2) { // Nếu lựa chọn nhỏ hơn 1 hoặc lớn hơn 2 hiển thị lỗi.
                        throw new InputMismatchException("Lựa chọn của bạn không hợp lệ.");
                    } else if (choose == 1) { // Nếu lựa chọn là 1 thì thêm nhân viên thường.
                        Employee staffs = new Employee();
                        enterEmpInformation(staffs);
                        arrStaffs.add(staffs);
                    } else if (choose == 2) { // Nếu lựa chọn là 2 thì thêm quản lý cấp cao.
                        Manager staffs = new Manager();
                        enterManagerInformation(staffs);
                        arrStaffs.add(staffs);
                    }
                }
                System.out.println();
            } else if (answer == 5) { // Nếu answer là 5 thì tìm kiếm thông tin nhân viên theo mã hoặc theo tên nhân viên.
                SearchEmpByNameOrID(arrStaffs);
                System.out.println();
            } else if (answer == 6) { // Nếu answer là 6 thì hiển thị lương của nhân viên theo thứ tự giảm dần.
                displayEmpSalary(arrStaffs, count);
                System.out.println();
            } else if (answer == 7) { // Nếu answer là 7 thì hiển thị lương của nhân viên theo thứ tự tăng dần.
                displaySortSalary(arrStaffs, count);
                System.out.println();
            }
        } while(true);
    }

    /*********************************************
     * Hàm được sử dụng để hiển thị thông tin của
     * tất cả các nhân viên trong công ty.
     * Các tham số được truyền vào hàm là ArrayList
     * <Staff> arrStaffs có lưu thông tin của các
     * nhân viên trong công ty.
     *********************************************/
    public static void displayAllEmp(ArrayList<Staff> arrStaffs) {
        System.out.println("Danh sách các nhân viên trong công ty");
        for(Staff st : arrStaffs) { // Chạy vòng lặp và hiển thị thông tin của từng nhân viên trong công ty.
            System.out.println(st.displayInformation());
        }
    }

    /*********************************************
     * Hàm được sử dụng để nhập thông tin của nhân
     * viên thường.
     * Các tham số được truyền vào hàm là Employee
     * staff để nhập các thông tin của quản lý.
     *********************************************/
    public static void enterEmpInformation(Employee staff) {
        // Yêu cầu người dùng nhập thông tin tương ứng cho nhân viên mới thêm vào.
        System.out.print("Id: ");
        staff.setId(input.nextInt());
        input.nextLine();
        System.out.print("Tên: ");
        staff.setTen(input.nextLine());
        System.out.print("Tuổi: ");
        staff.setTuoi(input.nextInt());
        System.out.print("Hệ số lương: " );
        staff.setHeSoLuong(input.nextDouble());
        input.nextLine();
        System.out.print("Ngày bắt đầu: ");
        staff.setNgayBatDau(input.nextLine());
        System.out.print("Bộ phận làm việc (1. Project, 2. Technique, 3. Business): ");
        String inputDepartmentName = input.next();
        Department found = null;
        for (Department item: departmentList) { // chạy vòng lặp
            if (item.getTenBoPhan().equalsIgnoreCase(inputDepartmentName)) { // Điều kiện nếu item.getTenBoPhan() giống với tên bộ phận người dùng nhập vào.
                found = item; // Department found = Department item.
                break;
            }
        }
        if (found == null) { // Điều kiện nếu found = null thì hiển thị thông báo lỗi.
            throw new Error("Không tìm thấy bộ phận");
        }
        staff.setBoPhanLamViec(found); // Thiết lập bộ phận làm việc cho nhân viên là bằng found.
        found.setSoNhanVienBoPhan(found.getSoNhanVienBoPhan() + 1); // Sau mỗi lần thêm vào bộ phận thì số nhân viên trong bộ phận tăng lên 1.
        System.out.print("Số ngày nghỉ phép: ");
        staff.setNgayNghiPhep(input.nextInt());
        System.out.print("Số giờ làm thêm: ");
        staff.setSoGioLamThem(input.nextInt());
    }

    /*********************************************
     * Hàm được sử dụng để nhập thông tin của quản
     * lý.
     * Các tham số được truyền vào hàm là Manager
     * Staff để nhập các thông tin của quản lý.
     *********************************************/
    public static void enterManagerInformation(Manager staff) {
        // Yêu cầu người dùng nhập thông tin tương ứng cho quản lý mới thêm vào.
        System.out.print("Id: ");
        staff.setId(input.nextInt());
        input.nextLine();
        System.out.print("Tên: ");
        staff.setTen(input.nextLine());
        System.out.print("Tuổi: ");
        staff.setTuoi(input.nextInt());
        System.out.print("Hệ số lương: " );
        staff.setHeSoLuong(input.nextDouble());
        input.nextLine();
        System.out.print("Ngày bắt đầu: ");
        staff.setNgayBatDau(input.nextLine());
        System.out.print("Bộ phận làm việc (1. Project, 2. Technique, 3. Business): ");
        String inputDepartmentName = input.next();
        Department found = null;
        for (Department item: departmentList) { // chạy vòng lặp
            if (item.getTenBoPhan().equalsIgnoreCase(inputDepartmentName)) { // Điều kiện nếu item.getTenBoPhan() giống với tên bộ phận người dùng nhập vào.
                found = item; // Department found = Department item.
                break;
            }
        }
        if (found == null) { // Điều kiện nếu found = null thì hiển thị thông báo lỗi.
            throw new Error("Không tìm thấy bộ phận");
        }
        staff.setBoPhanLamViec(found); // Thiết lập bộ phận làm việc cho quản lý là bằng found.
        found.setSoNhanVienBoPhan(found.getSoNhanVienBoPhan() + 1); // Sau mỗi lần thêm vào bộ phận thì số nhân viên trong bộ phận tăng lên 1.
        System.out.print("Số ngày nghỉ phép: ");
        staff.setNgayNghiPhep(input.nextInt());
        input.nextLine();
        System.out.print("Chức danh: ");
        staff.setChucDanh(input.nextLine());
    }

    /*********************************************
     * Hàm được sử dụng để hiển thị danh sách các
     * bộ phận trong công ty.
     *********************************************/
    public static void DisplayDepartmentInformation() {
        System.out.println("Danh sách các bộ phận trong công ty: ");
        for(Department dp : departmentList) { // Chạy vòng lặp và hiển thị từng bộ phận và thông tin các bộ phận trong công ty.
            System.out.println(dp.toString());
        }
    }

    /*********************************************
     * Hàm được sử dụng để hiển thị các nhân viên
     * theo từng bộ phận. (Project, Technique và
     * Business.
     * Các tham số được truyền vào hàm là ArrayList
     * <Staff>arrStaff chứa các nhân viên.
     *********************************************/
    public static void ShowAllEmpInDepartment(ArrayList<Staff> arrStaff) {
        // Yêu cầu người dùng nhập tên bộ phận mà họ muốn hiển thị nhân viên.
        System.out.println("Nhập bộ phận mà bạn muốn hiển thị nhân viên (1. Project, 2. Technique, 3. Business): ");
        String departName = input.next();
        for(Staff staff : arrStaff) {
            if(staff.displayInformation().contains(departName)) { // Điều kiện nếu staff.displayInformation() có chứa tên của bộ phận người dùng nhập vào.
                System.out.println(staff.displayInformation()); // hiển thị thông tin nhân viên trong bộ phận.
            }
        }
    }

    /*********************************************
     * Hàm được sử dụng để tìm kiếm thông tin nhân
     * viên theo tên hoặc mã nhân viên. Nếu không
     * tìm thấy tên hoặc mã của nhân viên chương
     * trình sẽ trả lại thông báo không tìm thấy
     * cho người dùng.
     * Các tham số được truyền vào hàm là ArrayList
     * <Staff>arrStaff chứa các nhân viên.
     *********************************************/
    public static void SearchEmpByNameOrID(ArrayList<Staff> arrStaff) {
        // Hiển thị lựa chọn tìm theo tên và mã cho người dùng sau đó yêu cầu người dùng nhâp lựa chọn.
        System.out.println("Chọn kiểu tìm kiếm mà bạn muốn sử dụng: ");
        System.out.println("1. Tìm kiếm theo tên.");
        System.out.println("2. Tìm kiếm theo mã nhân viên.");
        System.out.print("Lựa chọn: ");
        int choose = input.nextInt();
        int check = 0; // biến check được tạo để kiểm tra tên hoặc mã nhân viên tồn tại hay không.
        if(choose < 1 || choose > 2) { // Nếu lựa chọn nhỏ hơn 1 hoặc lớn hơn 2 -> Thông báo lỗi.
            throw new InputMismatchException("Lựa chọn của bạn không hợp lệ");
        } else if(choose == 1) { // Nếu lựa chọn 1 yêu cầu người dùng nhập tên cần tìm kiếm.
            System.out.print("Nhập tên nhân viên bạn muốn tìm kiếm: ");
            String tenNV = input.next();
            for(Staff staff : arrStaff) { // Chạy vòng lặp
                if(staff.toString().contains(tenNV)) { // Điều kiện nếu staff có chứa tên nhân viên mà người dùng nhập vào.
                    System.out.println(staff.toString()); // Hiển thị thông tin nhân viên người dùng tìm.
                    check = 1;
                    break;
                }
            }
            if(check == 0) { // Nếu tên nhân viên không tồn tại check = 0 và hiển thị tin nhắn thông báo không tìm thấy cho người dùng.
                System.out.println("Tên nhân viên bạn tìm không tồn tại.");
            }
        } else if(choose == 2) { // Nếu lựa chọn 2 yêu cầu người dùng nhập mã cần tìm kiếm.
            System.out.print("Nhập mã nhân viên bạn muốn tìm kiếm: ");
            int maNV = input.nextInt();
            for (Staff staff : arrStaff) {
                if (staff.getId() == maNV) { // Điều kiện nếu staff.getId() == mã nhân viên người dùng nhập vào.
                    System.out.println(staff.toString()); // Hiển thị thông tin người dùng tìm.
                    check = 1;
                    break;
                }
            }
            if(check == 0) { // Nếu mã nhân viên không tồn tại check = 0 và hiển thị tin nhắn thông báo không tìm thấy cho người dùng.
                System.out.println("Mã nhân viên bạn tìm không tồn tại.");
            }
        }
    }

    /*********************************************
     * Hàm được sử dụng để hiển thị lương của nhân
     * viên theo thứ tự giảm dần
     * Các tham số được truyền vào hàm là ArrayList
     * <Staff>arrStaff chứa các nhân viên và biến
     * soNhanvien dạng int.
     *********************************************/
    public static void displayEmpSalary(ArrayList<Staff> arrStaff, int soNhanvien) {
        System.out.println("Hiển thị lương của các nhân viên trong công ty: ");
        // tạo 1 array dạng int tên arr để chứa lương của các nhân viên và 1 array dạng String tên str để chứa thông tin hiển thị của từng nhân viên tương ứng.
        int[] arr = new int[soNhanvien];
        String[] str = new String[soNhanvien];
        int i = 0;
        for(Staff staff : arrStaff) { // chạy vòng lặp để gán giá trị lương và thông tin hiển thị của từng nhân viên vào các array tương ứng.
            arr[i] = staff.calculateSalary();
            str[i] = staff.displayInformation();
            i++;
        }
        int j = 0;
        for(i = 0; i < soNhanvien - 1; i++) {
            for(j = i + 1; j < soNhanvien; j++) {
                if(arr[i] < arr[j]) { // điều kiện nếu arr[i] < arr[j] thì ta hoán đổi str[i] với str[j]
                    String temp = str[i];
                    str[i] = str[j];
                    str[j] = temp;
                }
            }
        }
        // Hiển thị lương của nhân viên theo thứ tự giảm dần.
        for(i = 0; i < soNhanvien; i++) {
            System.out.println(str[i]);
        }
    }

    /*********************************************
     * Hàm được sử dụng để hiển thị lương của nhân
     * viên theo thứ tự tăng dần
     * Các tham số được truyền vào hàm là ArrayList
     * <Staff>arrStaff chứa các nhân viên và biến
     * soNhanvien dạng int.
     *********************************************/
    public static void displaySortSalary(ArrayList<Staff> arrStaff, int soNhanvien) {
        System.out.println("Hiển thị bảng lương của nhân viên theo thứ tự tăng dần: ");
        // tạo 1 array dạng int tên arr để chứa lương của các nhân viên và 1 array dạng String tên str để chứa thông tin hiển thị của từng nhân viên tương ứng.
        int[] arr = new int[soNhanvien];
        String[] str = new String[soNhanvien];
        int i = 0;
        for(Staff staff : arrStaff) { // chạy vòng lặp để gán giá trị lương và thông tin hiển thị của từng nhân viên vào các array tương ứng.
            arr[i] = staff.calculateSalary();
            str[i] = staff.displayInformation();
            i++;
        }
        int j = 0;
        for(i = 0; i < soNhanvien - 1; i++) {
            for(j = i + 1; j < soNhanvien; j++) {
                if(arr[i] > arr[j]) { // điều kiện nếu arr[i] > arr[j] thì ta hoán đổi str[i] với str[j]
                    String temp = str[i];
                    str[i] = str[j];
                    str[j] = temp;
                }
            }
        }
        // Hiển thị lương của nhân viên theo thứ tự tăng dần.
        for(i = 0; i < soNhanvien; i++) {
            System.out.println(str[i]);
        }
    }
}

