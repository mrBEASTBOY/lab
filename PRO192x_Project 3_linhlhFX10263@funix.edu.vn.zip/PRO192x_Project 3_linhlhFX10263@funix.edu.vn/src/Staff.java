import java.util.ArrayList;
import java.util.Scanner;

public abstract class Staff implements ICalculator{
    private int id; // ma nhan vien.
    private String ten; // ten nhan vien.
    private int tuoi; // tuoi nhan vien.
    private double heSoLuong; // he so luong.
    private String ngayBatDau; // ngay bat dau.
    private Department boPhanLamViec; // bo phan lam viec.
    private int ngayNghiPhep; // so ngay nghi phep.

    // Container.
    public Staff() {
        super();
    }
    public Staff(int id, String ten, int tuoi, double heSoLuong, String ngayBatDau, Department boPhanLamViec, int ngayNghiPhep) {
        super();
        this.id = id;
        this.ten = ten;
        this.tuoi = tuoi;
        this.heSoLuong = heSoLuong;
        this.ngayBatDau = ngayBatDau;
        this.boPhanLamViec = boPhanLamViec;
        this.ngayNghiPhep = ngayNghiPhep;
    }

    // Getter.
    public int getId() {
        return id;
    }
    public String getTen() {
        return ten;
    }
    public int getTuoi() {
        return tuoi;
    }
    public double getHeSoLuong() {
        return heSoLuong;
    }
    public String getNgayBatDau() {
        return ngayBatDau;
    }
    public Department getBoPhanLamViec() {
        return boPhanLamViec;
    }
    public int getNgayNghiPhep() {
        return ngayNghiPhep;
    }

    // Setter.
    public void setId(int id) {
        this.id = id;
    }
    public void setTen(String ten) {
        this.ten = ten;
    }
    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }
    public void setHeSoLuong(double heSoLuong) {
        this.heSoLuong = heSoLuong;
    }
    public void setNgayBatDau(String ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }
    public void setNgayNghiPhep(int ngayNghiPhep) {
        this.ngayNghiPhep = ngayNghiPhep;
    }
    public void setBoPhanLamViec(Department boPhanLamViec) {
        this.boPhanLamViec = boPhanLamViec;
    }

    public abstract String displayInformation();
    public abstract int calculateSalary();

    public String toString() {
        return "ID: " + this.id + ", Tên: " + this.ten + ", Tuổi: " + this.tuoi + ", Hệ số lương: " + this.heSoLuong + ", Ngày bắt đầu: " + this.ngayBatDau + ", Bộ phân làm việc: " + this.boPhanLamViec + ", Số ngày nghỉ phép: " + this.ngayNghiPhep;
    }
}
